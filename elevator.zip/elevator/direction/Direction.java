package elevator.direction;

public enum Direction {
    UP,
    DOWN,
    STILL
}
