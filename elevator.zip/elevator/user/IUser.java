package elevator.user;

public interface IUser {
    public String getName();
}
