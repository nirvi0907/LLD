package elevator.floor;

public class Floor {
    private int num;

    public Floor(int num){
        this.num = num;
    }
    public int getNum(){
        return num;
    }
}
