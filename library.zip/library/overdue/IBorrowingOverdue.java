package library.overdue;

public interface IBorrowingOverdue {
    public void areBooksOverdue();
}
