package library.Notifier;

import library.account.IBorrower;

import java.util.List;

public class Notifier implements IBorrowingNotifier {
    List<IBorrower> borrowers;
    public void addBorrower(IBorrower borrower){

    }
    public void removeBorrower(IBorrower borrower){

    }
    public void notifyBorrower(IBorrower borrower){

    }
}
