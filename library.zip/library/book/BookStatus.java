package library.book;

public enum BookStatus {
    AVAILABLE,
    NOT_AVAILABLE
}
