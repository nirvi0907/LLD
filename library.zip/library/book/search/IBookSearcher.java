package library.book.search;

import library.book.IBook;

public interface IBookSearcher {
    public IBook searchBook(String name);
}
