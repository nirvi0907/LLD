package library.account;

public interface INotifiable {
    public void update(String message);
}
