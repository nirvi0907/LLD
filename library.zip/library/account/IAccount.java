package library.account;

public interface IAccount {
    public String get_Name();
    public String getPhone();
    public String getEmail();
    public int get_Id();
}
