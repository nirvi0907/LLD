package elevator.door;

public enum DoorState {
    OPEN,
    CLOSE
}
