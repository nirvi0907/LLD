package elevator.elevator.panel;

import elevator.floor.Floor;

import java.util.List;

public class Panel implements IPanel {
    public List<Floor> getFloors(){
        return null;
    }
    public List<Floor> getPressedFloors(){
        return null;
    }
}
